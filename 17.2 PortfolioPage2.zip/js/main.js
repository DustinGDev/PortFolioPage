//For the Links to work

var figElems = document.getElementsByClassName('project-figs');
var arrLength = figElems.length;

for (i = 0; i < arrLength; i++){
  figElems[i].addEventListener('click', forwardToProject);
};

function forwardToProject(){
  var elemId = this.id;
  var link

  switch (elemId){
    case "storyP":
        link = "http://creativus-webart.de/StoryProject/index.php";
        break;
    case "creativusP":
        link = "http://creativus-webart.de";
        break;
    case "tradingCardP":
        link = "https://zero334433.github.io/AnimalTradingCard/card.html";
        break;
    default:
        link = "index.html";
        break;
  }

  var page = window.open(link, '_blank');
  page.focus();
}
